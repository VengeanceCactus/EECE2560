/*Project 4a board class written by Andrew Ricci*/

#include <string>
#include <vector>

using namespace std;

class Board{
public:
    Board(string filename1);
    void printBoard();
    void addValue(char value, int row1, int col1);
    void clearValue(int row1, int col1);
    void checkSolved();
    int checkConflicts(int row, int col);

    vector<vector<char>> sudokuBoard;
    vector<vector<bool>> rowConflictValues;
    vector<vector<bool>> colConflictValues;
    vector<vector<bool>> gridConflictValues;
    int size;
};
