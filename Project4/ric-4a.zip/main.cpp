/*Project 4a main program written by Andrew Ricci */

#include "board.h"
#include <iostream>

using namespace std;

int main(){
    string filename;
    cout << "Please input filename to initialize board."<<endl;
    cin >> filename;
    //initializes sudoku board from file
    Board board1(filename);
    board1.printBoard();
    //clears a value from top row and adds conflicting value
    board1.clearValue(0,5);
    board1.addValue('7',0,0);
    board1.printBoard();
    //checks if board is solved
    board1.checkSolved();

}
