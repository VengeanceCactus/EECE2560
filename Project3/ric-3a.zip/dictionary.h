/*Written by Andrew Ricci */

#include <vector>
#include <string>

using namespace std;

class Dictionary{
public:
    vector<string> dict;

    Dictionary();
    //reads from dictionary file and saves as vector
    void readDict();
    //overloaded operator that will print list of words
    void printDict();
    //sorts words using selection sort
    void sortDict(int ch1);
    //finds words using binary search
    void findWord(string search1);

};
